# GD Impossible Mod v0.1.0

Android/Geode prototype.

## Current status
- Minimal Geode mod entry point that logs when the mod loads.
- This is not yet the complete Impossible Mode UI or obstacle implementation.
- Build it for the exact Geode/Geometry Dash version used on the target device and test before use.
