#include <Geode/Geode.hpp>

using namespace geode::prelude;

// Prototype only: verifies the mod loads in Geode.
// The gameplay obstacle system is not implemented yet.
$on_mod(Loaded) {
    log::info("GD Impossible Mod v0.1.0 loaded.");
}
