# GD Impossible Mod v0.1.0 — Android starter

This is source code, not an already-built `.geode` file.

## Build without a PC
1. Create/sign in to a GitHub account and create a new **public** repository (or private if Actions is enabled).
2. Upload all files from this folder to the repository, preserving `.github/workflows/build.yml`.
3. Open the repository's **Actions** tab and run **Build Geode Android mod** (or push to `main`).
4. Check both build jobs. If they fail, open the job log; the source has not been verified as buildable until a job succeeds.
5. Download the `geode-android64` or `geode-android32` artifact from the completed workflow run.
6. Install the `.geode` file through Geode only if it matches your Geometry Dash/Geode version.

## Important
This prototype only logs that it loaded. It does NOT yet add obstacles or a custom menu.
The workflow's Geode SDK version may need to be updated to match the installed Geode version.
